//creating game states
//declaring text sprite for adding score
//declaring the sprites

//declaring the game states
var LOGO = 2;
var PLAY = 1;
var END = 0;
var justText

var gameState = LOGO;
//declaring characters of the game
var asteroid, asteroidImage;
var rocket, rocketImage;
var star, starImage;
var saturn, saturnImage;
var earth, earthImage;
var mercury, mercuryImage;
var sun, sunImage;
var moon, moonImage;
var galaxy2, galaxy2Image;
var galaxy1, galaxy1Image;
var logo, logoImage
var astronaut, astronaut_image
var nicePlanet, nicePlanet_image;
var flare, flareImage;
var sound1, sound2, sound3;
var soundTrack;
var opener, openerImage;
//declaring sprites for end states
var gameOver, gameOverImage;
var restart, restartImage

//declaring groups
var asteroidsGroup;
var starsGroup;
var moonGroup;
var mercuryGroup;
var sunGroup;
var galaxy1Group;
var galaxy2Group;
var saturnGroup;
var earthGroup;
var astronautGroup;

//declaring  score 
var score;
var attempts;

//declaring edges
var edges;

//assigning images to sprites
function preload() {
  sunImage = loadImage("sun.png");
  logoImage = loadImage("Ast.png");
  moonImage = loadImage("moon.png");
  sound1 = loadSound("whatever.mp3");
  sound2 = loadSound("whatever.mp3");
  sound3 = loadSound("whatever.mp3");
  flareImage = loadImage("flare.png");
  earthImage = loadImage("earth.png");
  starImage = loadImage("startle.png");
  saturnImage = loadImage("saturn.png");
  soundTrack = loadSound("whatever.wav");
  galaxy2Image = loadImage("galaxy2.png");
  mercuryImage = loadImage("mercury.png");
  restartImage = loadImage("restart.png");
  openerImage = loadImage("Whatever.png");
  rocketImage = loadImage("rocketeer.png");
  galaxy1Image = loadImage("milkyWay.png");
  asteroidImage = loadImage("asteroid.png");
  gameOver_Image = loadImage("gameover.jpg");
  nicePlanet_Image = loadImage("nicePlanet.png");
  astronaut_Image = loadImage("Coolastronaut.png");
  rocketImage = loadImage("awesomerocketimage.png");
}

//setting the game up
function setup() {
  createCanvas(500, 300);
  //declaring rocket
  rocket = createSprite(250, 250, 20, 5);
  rocket.addImage("rocket", rocketImage);
  rocket.scale = 0.2;
  score = 0;
  attempts = 0;



  ///declaring groups
  asteroidsGroup = new Group();
  starsGroup = new Group();
  moonGroup = new Group();
  mercuryGroup = new Group();
  sunGroup = new Group();
  galaxy1Group = new Group();
  galaxy2Group = new Group();
  saturnGroup = new Group();
  earthGroup = new Group();
  astronautGroup = new Group();
  nicePlanetGroup = new Group();
  flareGroup = new Group();
  //Declaring logo
  logo = createSprite(250, 150, 10, 10);
  logo.addImage(logoImage);
  logo.scale = 1.2;
  logo.visible = true;
  //declaring message for clicking space
  opener = createSprite(230, 250, 10, 10);
  opener.addImage(openerImage);
  opener.scale = 0.2;
  opener.visible = true;
  //declaring sprites for end Game state
  gameOver = createSprite(250, 150, 10, 10);
  gameOver.addImage(gameOver_Image);
  gameOver.scale = 0.5;
  restart = createSprite(440, 150, 10, 10);
  restart.addImage(restartImage);
  restart.scale = 0.5;
  //setting for deciding time for end state sprites
  gameOver.x = 700;
  restart.x = 700
}


function draw() {

  textSize(20);
  text("Attempts: " + attempts, 299, 60); 
  ///creating edges
  edges = createEdgeSprites();
  if (gameState === LOGO) {
    soundTrack.play();

    //sound2.play();
    //sound3.play();
    background(260);
    rocket.visible = false;
    if (keyDown("space")) {
      gameState = PLAY;
    }
  }
  if (gameState === PLAY) {

    logo.visible = false;
    opener.visible = false;
    soundTrack.play();
    background(20);
    textSize(20);
    text("Score: " + score, 325, 30);
    score = score + Math.round(frameCount / 60);
    rocket.visible = true;
    if (keyDown("LEFT_ARROW")) {
      rocket.x = rocket.x - 24
    }
    if (keyDown("RIGHT_ARROW")) {
      rocket.x = rocket.x + 24;
    }
    if (rocket.x > 475) {
      rocket.x = 475;
    }
    if (rocket.x < 25) {
      rocket.x = 25;

    }
    asteroidShower();
    rocketVelocity();
    rocket.setCollider("circle", 0, 0, 150);


    if (asteroidsGroup.isTouching(rocket)) {

      attempts = attempts + 1;
      gameState = END;
      asteroid.velocityY = 0;
      sound1.play();
    }



  }
  if (gameState === END) {
    score.x = 250;
    gameOver.x = 250;
    restart.x = 440;
    asteroidsGroup.setVelocityYEach(0);
    asteroidsGroup.destroyEach();
    sunGroup.destroyEach();
    moonGroup.destroyEach();
    galaxy1Group.destroyEach();
    galaxy2Group.destroyEach();
    mercuryGroup.destroyEach();
    saturnGroup.destroyEach();
    earthGroup.destroyEach();
    astronautGroup.destroyEach();
    flareGroup.destroyEach();
    nicePlanetGroup.destroyEach();
    starsGroup.setVelocityYEach(0);
    rocket.x = 60;
    rocket.y = 150;

    if (mousePressedOver(restart)) {
      reset();
    }

  }
  drawSprites();
}
//adding obstacles
function asteroidShower() {
  if (frameCount % 25 === 0) {
    asteroid = createSprite(30, 0, 500, 500);
    asteroid.addImage("asteroid", asteroidImage);
    asteroid.setCollider("circle", 0, 40, 415);

    asteroid.x = Math.round(random(0, 500));
    asteroid.velocityY = 12;
    asteroid.scale = 0.09;
    //adding asteroids in asteroids group
    asteroidsGroup.add(asteroid);
    asteroid.depth = asteroid.depth + 5;
  }


}


//creating illusion for making rocket move
function rocketVelocity() {
  if (frameCount % 0.5 === 0) {
    star = createSprite(500, 0, 40, 10);
    star.x = Math.round(random(0, 500));
    star.addImage(starImage);
    star.velocityY = 45;
    star.depth = rocket.depth;
    rocket.depth = rocket.depth + 1;
    star.scale = 0.02;
    starsGroup.add(star);
  }

  if (frameCount % 425 === 0) {
    earth = createSprite(500, 0, 40, 10);
    earth.addImage(earthImage);
    earth.x = Math.round(random(0, 500));
    earth.scale = 0.4;
    earth.velocityY = 10;
    earthGroup.add(earth);



  }


  if (frameCount % 336 === 0) {
    saturn = createSprite(500, 0, 40, 10);
    saturn.addImage(saturnImage);
    saturn.x = Math.round(random(0, 500));
    saturn.scale = 0.4;
    saturn.velocityY = 20;
    saturnGroup.add(saturn);


  }

  if (frameCount % 243 === 0) {
    galaxy2 = createSprite(500, 0, 40, 10);
    galaxy2.addImage(galaxy2Image);
    galaxy2.x = Math.round(random(0, 500));
    galaxy2.scale = 0.4;
    galaxy2.velocityY = 15;
    galaxy2Group.add(galaxy2);
  }

  if (frameCount % 159 === 0) {
    galaxy1 = createSprite(500, 0, 40, 10);
    galaxy1.addImage(galaxy1Image);
    galaxy1.x = Math.round(random(0, 500));
    galaxy1.scale = 0.2;
    galaxy1.velocityY = 15;
    galaxy1Group.add(galaxy1);
  }

  if (frameCount % 744 === 0) {
    sun = createSprite(500, 0, 40, 10);
    sun.addImage(sunImage);
    sun.x = Math.round(random(0, 500));
    sun.scale = 0.5;
    sun.velocityY = 10;
    sunGroup.add(sun);

  }
  if (frameCount % 673 === 0) {
    mercury = createSprite(500, 0, 40, 10);
    mercury.addImage(mercuryImage);
    mercury.x = Math.round(random(0, 500));
    mercury.scale = 0.5;
    mercury.velocityY = 45;
    mercuryGroup.add(mercury);
  }
  if (frameCount % 288 === 0) {
    moon = createSprite(500, 0, 40, 10);
    moon.addImage(moonImage);
    moon.scale = 0.5;
    moon.x = Math.round(random(0, 500));
    moon.velocityY = 5;
    moonGroup.add(moon);

  }
  if (frameCount % 388 === 0) {
    astronaut = createSprite(0, 300, 40, 10);
    astronaut.addImage(astronaut_Image);
    astronaut.scale = 0.1;
    astronaut.y = Math.round(random(50, 150));
    astronaut.velocityX = 5;
    astronautGroup.add(astronaut);

  }
  if (frameCount % 456 === 0) {
    nicePlanet = createSprite(500, 0, 40, 10);
    nicePlanet.addImage(nicePlanet_Image);
    nicePlanet.scale = 0.3;
    nicePlanet.x = Math.round(random(0, 500));
    nicePlanet.velocityY = 5;
    nicePlanetGroup.add(nicePlanet);

  }
  if (frameCount % 233 === 0) {
    flare = createSprite(500, 0, 40, 10);
    flare.addImage(flareImage);
    flare.scale = 0.4;
    flare.x = Math.round(random(0, 500));
    flare.velocityY = 5;
    flareGroup.add(flare);

  }
}
//to reset te game
function reset() {
  gameState = PLAY;
  gameOver.x = 700;
  restart.x = 700;
  starsGroup.destroyEach();
  score = 0;
  rocket.y = 250;
  rocket.x = 250;

}